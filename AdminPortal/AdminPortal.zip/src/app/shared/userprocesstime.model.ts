export class UserProcessTimes {
    UserProcessTimeID: number;
    UserID: number;
    ProcessTimeID: number;
    MemRefNo:string;    
}
