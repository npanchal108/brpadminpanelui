export class ProcessTime {
    ProcessTimeID: number;
    ProcessTimeName: string;
    
}
