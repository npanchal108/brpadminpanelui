export class Menu {
    MenuID: number;
    Title: string;
    Linkurl: string;
    Rank: number;
    Active: string;
    ParentID: number;
    ButtenText:string="Submit";
    UserMemRefNo:string;
}


