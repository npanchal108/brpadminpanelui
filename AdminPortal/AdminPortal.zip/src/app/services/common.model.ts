export class Common {
   //RootUrl: string = 'http://localhost:38051';
   //RootUrl: string = 'https://portal.distone.com/adminportalapi';
   RootUrl:string='https://portal.distone.com/webapi';
   //RootUrl:string='https://portal4.distone.com/adminportalapi';
   userurl: string = 'https://portal.distone.com/';
}

