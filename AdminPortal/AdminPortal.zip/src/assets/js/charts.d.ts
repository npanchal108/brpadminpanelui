declare function initDemo():void;
export = initDemo;
